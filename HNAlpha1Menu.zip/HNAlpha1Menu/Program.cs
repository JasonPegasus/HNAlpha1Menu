﻿using HNAlpha1Menu;
using Swed64;
using System.Data;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography; // 2D and 3D Coords (Vectors?)

Console.SetWindowSize(50, 35);
Console.SetWindowPosition(0, 0);
Console.Title = "HNAlpha1 Console";
Console.ForegroundColor = ConsoleColor.DarkGreen;

Renderer renderer = new Renderer(); // instancia la clase del render, para que inicie el minimenu
renderer.Start().Wait(); // hace que esa instancia se inicie (corra)

// CUSTOM VARIABLES
Vector2 vAngles;
double degreeToRadian = Math.PI / 180;
double anglesOffset = 90 * degreeToRadian;
bool db = false;

// OFFSET OF POINTERS VARIABLES

Swed swed = new Swed("HelloNeighborReborn-Win64-Shipping");
IntPtr moduleBase = swed.GetModuleBase("HelloNeighborReborn-Win64-Shipping.exe");

int poiPlayer = 0x023930D0;
int poiPlayer2 = 0xF8;
int poiPlayer3 = 0x2A0;
int poiPosX = 0x120;
int poiPosZ = 0x124;
int poiPosY = 0x128;

int poiNeighbor = 0x02315E40;
int poiNeighbor2 = 0x78;
int poiNeighborPos = 0x160;
int poiNeighborX = 0x120;
int poiNeighborZ = 0x124;
int poiNeighborY = 0x128;

int poiCamera = 0x02399C40;
int poiCamRot = 0x30;
int poiCamX = 0x37C;
int poiCamY = 0x378;

IntPtr fall = moduleBase + 0x3CA1F8; // original = 0F 29 B3 20 01 00 00

void UpdateConsole()
{
    while (true) //MAIN LOOP
    {
        bool rKey = GetAsyncKeyState(0x52) < 0;
        if (rKey)
        { Reload(); }

        Thread.Sleep(5);
        Main();
    }
}
UpdateConsole();

void Reload()
{
    swed = new Swed("HelloNeighborReborn-Win64-Shipping");
    moduleBase = swed.GetModuleBase("HelloNeighborReborn-Win64-Shipping.exe");
}


float oldNPosX = 0;
float oldNPosY = 0;
float oldNPosZ = 0;

bool db2 = false;

void Main()
{
    // KEYS
    bool spaceKey = GetAsyncKeyState(0x20) < 0;
    bool controlKey = GetAsyncKeyState(0xA2) < 0;
    bool vKey = GetAsyncKeyState(0x56) < 0;
    bool wKey = GetAsyncKeyState(0x57) < 0;
    bool aKey = GetAsyncKeyState(0x41) < 0;
    bool sKey = GetAsyncKeyState(0x53) < 0;
    bool dKey = GetAsyncKeyState(0x44) < 0;
    bool xKey = GetAsyncKeyState(0x58) < 0;
    bool zKey = GetAsyncKeyState(0x5A) < 0;
    bool tKey = GetAsyncKeyState(0x54) < 0;

    // PLAYER POS
    var posX = swed.ReadPointer(moduleBase, poiPlayer, poiPlayer2, poiPlayer3) + poiPosX;
    var posY = swed.ReadPointer(moduleBase, poiPlayer, poiPlayer2, poiPlayer3) + poiPosY;
    var posZ = swed.ReadPointer(moduleBase, poiPlayer, poiPlayer2, poiPlayer3) + poiPosZ;

    // CAM POS
    var camX = swed.ReadPointer(moduleBase, poiCamera, poiCamRot) + poiCamX; //estos son solo pointers, no los valores. esta asi para que luego se pueda writear
    var camY = swed.ReadPointer(moduleBase, poiCamera, poiCamRot) + poiCamY;

    // NEIGHBOR POS
    var nPosX = swed.ReadPointer(moduleBase, poiNeighbor, poiNeighbor2, poiNeighborPos) + poiNeighborX;
    var nPosY = swed.ReadPointer(moduleBase, poiNeighbor, poiNeighbor2, poiNeighborPos) + poiNeighborY;
    var nPosZ = swed.ReadPointer(moduleBase, poiNeighbor, poiNeighbor2, poiNeighborPos) + poiNeighborZ;

    // --------------------------------------------- FLY --------------------------------------------- //


    // NOCLIP ON KEY
    if (vKey)
    {
        if (db == false)
        {
            db = true;
            renderer.fly = !renderer.fly;
        }
    }
    else
    { db = false; }

    if (xKey) { renderer.flySpeed *= 1.05f; }
    if (zKey) { renderer.flySpeed /= 1.05f; }

    // ACTUALLY FLY

    vAngles.X = swed.ReadFloat(camX);
    vAngles.Y = swed.ReadFloat(camY);

    float currPosX = swed.ReadFloat(posX);
    float currPosY = swed.ReadFloat(posY);
    float currPosZ = swed.ReadFloat(posZ);

    //calcular nuevas posiciones

    float addX = (float)(renderer.flySpeed * Math.Cos(vAngles.X * degreeToRadian - anglesOffset));
    float addY = (float)(renderer.flySpeed * Math.Sin(vAngles.X * degreeToRadian - anglesOffset));
    float addZ = (float)(renderer.flySpeed * Math.Sin(vAngles.Y * degreeToRadian));

    if (renderer.fly)
    {

        if (wKey)
        {
            swed.WriteFloat(posX, currPosX - addY);
            //swed.WriteFloat(posY, currPosY + addZ);
            swed.WriteFloat(posZ, currPosZ + addX);
        }

        if (sKey)
        {
            swed.WriteFloat(posX, currPosX + addY);
            //swed.WriteFloat(posY, currPosY + addZ);
            swed.WriteFloat(posZ, currPosZ - addX);
        }

        // UP AND DOWN
        if (spaceKey)
        {
            swed.WriteFloat(posY, swed.ReadFloat(posY) + renderer.flySpeed); // UP ON SPACE
        }
        if (controlKey)
        {
            swed.WriteFloat(posY, swed.ReadFloat(posY) - renderer.flySpeed); // DOWN ON CONTROL
        }
        swed.WriteBytes(fall, "90 90 90 90 90 90 90"); // DISABLES FALL

    }
    else
    {
        swed.WriteBytes(fall, "0F 29 B3 20 01 00 00"); // ENABLES FALL
    }


    // --------------------------------------------- FREEZE --------------------------------------------- //



    if (tKey)
    {
        if (db2 == false)
        {
            db2 = true;
            renderer.freezeNeighbor = !renderer.freezeNeighbor;
            oldNPosX = swed.ReadFloat(nPosX);
            oldNPosY = swed.ReadFloat(nPosY);
            oldNPosZ = swed.ReadFloat(nPosZ);

            if (renderer.freezePos.X != 0 & renderer.freezePos.Y != 0 & renderer.freezePos.Z != 0)
            {
                oldNPosX = renderer.freezePos.X;
                oldNPosY = renderer.freezePos.Y;
                oldNPosZ = renderer.freezePos.Z;
            }

            if (renderer.freezeNeighbor)
            {
                Console.WriteLine("- Neighbor freezed at:");
                Console.WriteLine("      X: " + oldNPosX + " Y: " + oldNPosY + " Z: " + oldNPosZ);
                if (renderer.freezeToPlayer)
                {
                    Console.WriteLine("      Relative to Player");
                }
            }
            else
            { Console.WriteLine("- Neighbor Unfreezed"); }
        }
    }
    else
    { db2 = false; }

    float neiCamX = (float)(Math.Cos(vAngles.X * degreeToRadian - anglesOffset));
    float neiCamY = (float)(Math.Sin(vAngles.X * degreeToRadian - anglesOffset));
    float neiCamZ = (float)(Math.Sin(vAngles.Y * degreeToRadian));

    if (renderer.freezeNeighbor)
    {
        if (renderer.freezeToPlayer)
        {
            oldNPosX = currPosX - neiCamY*200;
            oldNPosY = currPosY + 10 + neiCamZ*200;
            oldNPosZ = currPosZ + neiCamX*200;
        }
        swed.WriteFloat(nPosX, oldNPosX);
        swed.WriteFloat(nPosY, oldNPosY);
        swed.WriteFloat(nPosZ, oldNPosZ);
    }
}





[DllImport("user32.dll")]
static extern short GetAsyncKeyState(int key_Gravity);







/*EXPLICACION RAPIDA
var player = swed.ReadPointer(moduleBase, poiPlayer, poiPlayer2, poiPlayer3) + poiPosY;
                    |          |             |           |           |           |
       lee la direccion      base          child       child      child       lo que tiene que leer

en lugar de hacer ReadFloat(PLAYER, OFFSET), se le suma el offset poiPosY al "player", para solo tener que hacer ReadFloat(PLAYER), ya que el "+" fuciona para
predecir lo que vas a leer
*/
