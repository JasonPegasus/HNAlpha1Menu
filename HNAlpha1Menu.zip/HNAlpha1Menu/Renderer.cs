﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using ClickableTransparentOverlay;
using ImGuiNET;

namespace HNAlpha1Menu
{
    public class Renderer : Overlay
    {
        public bool fly = false;
        public float flySpeed = 10;
        public bool freezeNeighbor = false;
        public bool freezeToPlayer = false;
        public Vector3 freezePos = new Vector3(0, 0, 0);
        Vector4 red = new Vector4(1, 1, 0, 255);
        Vector4 grey = new Vector4(0.4f, 0.4f, 0.4f, 255);

        protected override void Render() // FUNCION de render, cada frame
        {
            ImGui.Begin("HNAlpha1Menu");
            ImGui.StyleColorsDark();
            ImGui.TextColored(red, "R to Reload");
            ImGui.Spacing();

            ImGui.Checkbox("Fly", ref fly);
            ImGui.InputFloat("Fly Speed", ref flySpeed);
            ImGui.TextColored(red, "V to enable Fly");
            ImGui.TextColored(grey, "Z & X for -/+ speed");
            ImGui.Spacing();

            ImGui.Checkbox("Freeze Neighbor", ref freezeNeighbor);
            ImGui.TextColored(red, "T to enable Freeze");
            ImGui.InputFloat3("Freeze at", ref freezePos);
            ImGui.TextColored(grey, "(0 means disabled)");
            ImGui.TextColored(grey, "(refreeze to update)");
            ImGui.Checkbox("Freeze relative to Player", ref freezeToPlayer);
            ImGui.TextColored(grey, "(may break AI pathfind)");
        }
    }
}
